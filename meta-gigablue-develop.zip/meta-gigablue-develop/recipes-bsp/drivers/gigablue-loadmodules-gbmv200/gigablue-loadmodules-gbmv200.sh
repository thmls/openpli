#!/bin/sh

echo "gigablue start!!!"
cd /lib/modules/4.4.35/extra/
./load
